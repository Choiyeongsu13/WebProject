package com.mnu.sample.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Action {
	public void process(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException;

}
