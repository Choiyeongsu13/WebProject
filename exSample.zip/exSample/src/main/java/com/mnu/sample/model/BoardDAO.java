package com.mnu.sample.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mnu.sample.util.DBManager;

public class BoardDAO {
//	
//	Connection conn = null;
//	String myDriver="oracle.jdbc.OracleDriver";
//	String myURL="jdbc:oracle:thin:@localhost:1521:xe";
//	String myID="c##sample";
//	String myPass="1234";
//	private Connection getConnection() {
//		try {
//			Class.forName(myDriver);
//			conn = DriverManager.getConnection(myURL, myID, myPass);
//		}catch(Exception e) {
//			e.printStackTrace();
//		}return conn;
//	}
	
	
	private BoardDAO() {}
	public static BoardDAO board = new BoardDAO();
	public static BoardDAO getInstance() {
		return board;
	}

	//메소드
	
	Connection conn=null;
	PreparedStatement pstmt=null;
	ResultSet rs= null;
	
	//전체 게시글 목록(list) - (검색, 페이지인덱스 없음) 메소드
	public List<BoardDTO> boardList(){
		List<BoardDTO> Blist = new ArrayList();
		String sql="select * from tbl_board ORDER by regdate desc";
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				BoardDTO Bdto = new BoardDTO();
				Bdto.setIdx(rs.getInt("idx"));
				Bdto.setName(rs.getString("name"));
				Bdto.setRegdate(rs.getString("regdate"));
				Bdto.setSubject(rs.getString("subject"));
				Bdto.setReadcnt(rs.getInt("readcnt"));
				
				Blist.add(Bdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
		DBManager.close(conn	, pstmt, rs);
		}return Blist;
	}
	//총 게시글 수 카운트
	public int boardcountList(){
		int count = 0;
		String sql="select count(*) from tbl_board";
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
		DBManager.close(conn	, pstmt, rs);
		}return count;
	}
	
	public int boardwrite(BoardDTO dto){
		int row=0;
		String sql = "insert into tbl_board(name,email,subject,contents,pass)\r\n"
				+ "values(?,?,?,?,?)";
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getEmail());
			pstmt.setString(3, dto.getSubject());
			pstmt.setString(4, dto.getContents());
			pstmt.setString(5, dto.getPass());
			row=pstmt.executeUpdate();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt);
		}return row;
	}
	

	
	
}
